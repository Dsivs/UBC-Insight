index.html is gateway/interface for actual implemntation
images used is for demo purpose only. (shows basic ideal how hovel/button/link works)
subject to change
