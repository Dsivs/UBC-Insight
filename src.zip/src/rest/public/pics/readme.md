this folder is used to contain all images that will be used for html
