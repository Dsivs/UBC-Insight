/**
 * Created by Axiaz on 2017-03-25.
 */
function sure() {
    var r = confirm('Are you ready to submit?');
    if (r == true) {
        doStuff();
    } else {
        alert('cancel');
    }
}

function doStuff() {

    var query = {
        "WHERE": {
        },
        "OPTIONS": {
            "COLUMNS": [
                "rooms_name"
            ],
            "FORM": "TABLE"
        }
    };

    var array = [];


    var form = document.getElementById("main-form");
    var formData = new FormData(form);

    //1 = AND, 2 = OR
    var typeOfQuery = formData.get("type");
    if (typeOfQuery == 1)
        query.WHERE.AND = array;
    else
        query.WHERE.OR = array;

    //1 = checked
    var room = formData.get("roomToggle");
    if (room == 1) {
        var roomVal = formData.get("room");
        console.log(roomVal);
        array.push({"IS": {"rooms_number": roomVal}});
    }

    var building = formData.get("buildingToggle");
    //console.log(building);
    if (building == 1) {
        var buildingVal = formData.get("building");
        array.push({"IS": {"rooms_shortname": buildingVal}});
    }

    var size = formData.get("sizeToggle");
    console.log(size);
    if (size == 1) {
        var compType = formData.get("compType");
        var sizeVal = parseInt(formData.get("size"));
        switch (compType) {
            case "1":
                array.push({"GT": {"rooms_seats": sizeVal}});
                break;
            case "2":
                array.push({"EQ": {"rooms_seats": sizeVal}});
                break;
            case "3":
                array.push({"LT": {"rooms_seats": sizeVal}})
        }
    }

    var roomType = formData.get("roomTypeToggle");
    if (roomType == 1) {
        var roomTypeVal = formData.get("roomType");
        array.push({"IS": {"rooms_type": roomTypeVal}});
    }
    //console.log(roomType);

    var furniture = formData.get("furnitureToggle");
    if (furniture == 1) {
        var furnitureVal = formData.get("building");
        array.push({"EQ": {"rooms_furniture": furnitureVal}});
    }

    console.log(JSON.stringify(query, null, 4));

        $.ajax({
            url: 'http://localhost:63342/query',
            type: 'POST',
            data: JSON.stringify(query),
            dataType: 'json',
            crossOrigin: true,
            cache: false,
            contentType: 'application/json'
        }).done( function(data){
            //data will be the result json obj
            console.log('response: ' + data);
            generateTable(data.result);
        }).fail( function(err){
            console.log(err);
        });
}

function generateTable(data) {
    var tbl_body = document.createElement("tbody");
    var odd_even = false;
    console.log("DATA", data);
    $.each(data, function() {
        var tbl_row = tbl_body.insertRow();
        tbl_row.className = odd_even ? "odd" : "even";
        $.each(this, function(k , v) {
            var cell = tbl_row.insertCell();
            cell.appendChild(document.createTextNode(v.toString()));
        });
        odd_even = !odd_even;
    });
    document.getElementById("tblResults").appendChild(tbl_body);
    // $("#tblResults").appendChild(tbl_body);
}