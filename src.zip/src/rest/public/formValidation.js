/**
 * Created by Axiaz on 2017-03-25.
 */
function sure() {
    doStuff();
    var r = confirm('Are you ready to submit?');
    if (r == true) {
        doStuff();
    } else {
        alert('cancel');
    }
}

function doStuff() {

    var query = {
        "WHERE": {
        },
        "OPTIONS": {
            "COLUMNS": [
                "rooms_name"
            ],
            "FORM": "TABLE"
        }
    };

    var array = [];


    var form = document.getElementById("main-form");
    var formData = new FormData(form);

    //1 = AND, 2 = OR
    var typeOfQuery = formData.get("type");
    if (typeOfQuery == 1)
        query.WHERE.AND = array;
    else
        query.WHERE.OR = array;

    //1 = checked
    var room = formData.get("roomToggle");
    if (room == 1) {
        var roomVal = formData.get("room");
        console.log(roomVal);
        array.push({"IS": {"rooms_number": roomVal}});
    }

    var building = formData.get("buildingToggle");
    //console.log(building);
    if (building == 1) {
        var buildingVal = formData.get("building");
        array.push({"IS": {"rooms_shortname": buildingVal}});
    }

    var size = formData.get("sizeToggle");
    console.log(size);
    if (size == 1) {
        var compType = formData.get("compType");
        var sizeVal = parseInt(formData.get("size"));
        switch (compType) {
            case "1":
                array.push({"GT": {"rooms_size": sizeVal}})
                break;
            case "2":
                array.push({"EQ": {"rooms_size": sizeVal}})
                break;
            case "3":
                array.push({"LT": {"rooms_size": sizeVal}})
        }
    }

    var roomType = formData.get("roomTypeToggle");
    if (roomType == 1) {
        var roomTypeVal = formData.get("roomType");
        array.push({"IS": {"rooms_type": roomTypeVal}});
    }
    //console.log(roomType);

    var furniture = formData.get("furnitureToggle");
    if (furniture == 1) {
        var furnitureVal = formData.get("building");
        array.push({"EQ": {"rooms_furniture": furnitureVal}});
    }

    console.log(JSON.stringify(query, null, 4));


}