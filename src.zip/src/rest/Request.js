"use strict";
var Util_1 = require("../Util");
var InsightFacade_1 = require("../controller/InsightFacade");
var insight = new InsightFacade_1.default();
var Request = (function () {
    function Request() {
    }
    Request.echo = function (req, res, next) {
        Util_1.default.trace('Server::echo(..) - params: ' + JSON.stringify(req.params));
        var promise = new Promise(function (fulfill, reject) {
            Request.handleReq(req).then(function (responding) {
                res.json(responding.code, responding.body);
                fulfill();
            }).catch(function (err) {
                res.json(err.code, err.body);
                reject();
            });
        });
        promise.then(function (res) {
            return next();
        }).catch(function (err) {
            return next();
        });
    };
    Request.handleReq = function (req) {
        Util_1.default.trace('begin handleReg');
        var method = req.method;
        return new Promise(function (fulfill, reject) {
            switch (method) {
                case 'PUT':
                    var data = req.params.body;
                    console.log("HI");
                    console.log(data);
                    try {
                        data = data.toString("base64");
                        insight.addDataset(req.params.id, data)
                            .then(function (respond) {
                            Util_1.default.trace('PUT addDataSet THEN:');
                            fulfill(respond);
                        })
                            .catch(function (err) {
                            Util_1.default.trace('PUT addDataSet CATCH:');
                            reject(err);
                        });
                    }
                    catch (err) {
                        reject({ "code": 400, "body": { "error": "problem with buffer" } });
                    }
                    break;
                case 'GET':
                    fulfill({ code: 200, body: {} });
                    break;
                case 'POST':
                    console.log("POST is called");
                    console.log("req.body = " + req.body);
                    insight.performQuery(JSON.parse(req.body)).then(function (res) {
                        console.log("fulfill with res = " + res);
                        fulfill(res);
                    }).catch(function (err) {
                        console.log(err);
                        reject(err);
                    });
                    break;
                case 'DELETE':
                    insight.removeDataset(req.params.id).then(function (respond) {
                        fulfill(respond);
                    }).catch(function (err) {
                        reject(err);
                    });
                    break;
                default:
                    reject(null);
            }
        });
    };
    return Request;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Request;
//# sourceMappingURL=Request.js.map