"use strict";
var Course_1 = require("./Course");
var util_1 = require("util");
var Room_1 = require("./Room");
var Util_1 = require("../Util");
var fs = require("fs");
var JSZip = require("jszip");
var http = require('http');
var roomArray = [];
var DataController = (function () {
    function DataController() {
        this.loadedCourses = [];
        this.loadedRooms = [];
    }
    DataController.prototype.addCourses = function (content) {
        var instance = this;
        var id = "courses";
        return new Promise(function (fulfill, reject) {
            instance.parseToZip(content)
                .then(function (zipContents) {
                return Promise.all(instance.readContents(zipContents));
            })
                .then(function (arrayOfFileContents) {
                return instance.parseFileContents(arrayOfFileContents);
            })
                .then(function (arrayOfJSONObj) {
                return instance.parseIntoCourses(arrayOfJSONObj);
            })
                .then(function (jsonData) {
                instance.loadedCourses = jsonData;
                return instance.cacheData(JSON.stringify(jsonData, null, 4), id);
            })
                .then(function (result) {
                fulfill(result);
            })
                .catch(function (err) {
                reject(err);
            });
        });
    };
    DataController.prototype.parseToZip = function (content) {
        return new Promise(function (fulfill, reject) {
            Util_1.default.trace("Datacontroller -> parse to zip");
            var zip = new JSZip();
            zip.loadAsync(content, { base64: true })
                .then(function (result) {
                Util_1.default.trace("Datacontroller -> parse to zip -> then");
                fulfill(result);
            })
                .catch(function (err) {
                Util_1.default.trace("Datacontroller -> parse to zip -> catch: err = " + err);
                reject({ "code": 400, body: { "error": "Content is not a valid base64 zip" } });
            });
        });
    };
    DataController.prototype.readContents = function (zipContents) {
        console.log('Datacontroller -> readContents -> START');
        var arrayOfFileContents = [];
        for (var filename in zipContents.files) {
            var file = zipContents.file(filename);
            if (file != null) {
                arrayOfFileContents.push(file.async("string"));
            }
        }
        console.log('Datacontroller -> readContents -> END');
        return arrayOfFileContents;
    };
    DataController.prototype.parseFileContents = function (arrayOfFileContents) {
        return new Promise(function (fulfill, reject) {
            console.log("Datacontroller -> parseFileContents -> start");
            var arrayOfJSONObj = [];
            for (var _i = 0, arrayOfFileContents_1 = arrayOfFileContents; _i < arrayOfFileContents_1.length; _i++) {
                var fileContent = arrayOfFileContents_1[_i];
                try {
                    arrayOfJSONObj.push(JSON.parse(fileContent));
                }
                catch (err) {
                    reject({ "code": 400, "body": { "error": "Zip contained no valid data" } });
                    console.log("This is not valid JSON:");
                }
            }
            if (arrayOfJSONObj.length == 0) {
                console.log("Datacontroller -> parseFileContents -> reject");
                reject({ "code": 400, "body": { "error": "Zip contained no valid data" } });
            }
            else {
                console.log("Datacontroller -> parseFileContents -> fulfill");
                fulfill(arrayOfJSONObj);
            }
        });
    };
    DataController.prototype.parseIntoCourses = function (arrayOfJSONObj) {
        var finalResult = [];
        return new Promise(function (fulfill, reject) {
            for (var _i = 0, arrayOfJSONObj_1 = arrayOfJSONObj; _i < arrayOfJSONObj_1.length; _i++) {
                var jsonObj = arrayOfJSONObj_1[_i];
                var jsonObjResultProp = jsonObj.result;
                if (Array.isArray(jsonObjResultProp)) {
                    for (var _a = 0, jsonObjResultProp_1 = jsonObjResultProp; _a < jsonObjResultProp_1.length; _a++) {
                        var section = jsonObjResultProp_1[_a];
                        var year = parseInt(section.Year);
                        if (section.Section === "overall")
                            year = 1900;
                        finalResult.push(new Course_1.default(section.Subject, section.Course, section.Avg, section.Professor, section.Title, section.Pass, section.Fail, section.Audit, section.id.toString(), year));
                    }
                }
            }
            if (finalResult.length == 0) {
                reject({ "code": 400, "body": { "error": "Zip contained no valid data" } });
            }
            else {
                fulfill(finalResult);
            }
        });
    };
    DataController.prototype.addRooms = function (content) {
        roomArray.length = 0;
        var instance = this;
        var id = "rooms";
        return new Promise(function (fulfill, reject) {
            instance.parseToZip(content)
                .then(function (zipContents) {
                return Promise.all(instance.room_readValidContents(zipContents));
            })
                .then(function (contentArray) {
                return instance.room_parseContent(contentArray);
            }).then(function (array) {
                console.log("parseContent is alright");
                return instance.room_validator(array);
            }).then(function (array) {
                console.log("validator is alright");
                return instance.room_addGeo(array);
            })
                .then(function (geoMapping) {
                instance.room_mapAddrToGeo(geoMapping);
                instance.loadedRooms = roomArray;
                return instance.cacheData(JSON.stringify(roomArray, null, 4), id);
            })
                .then(function (result) {
                fulfill(result);
            })
                .catch(function (err) {
                reject(err);
            });
        });
    };
    DataController.prototype.room_readValidContents = function (zipContents) {
        var contents = [];
        var instance = this;
        for (var filename in zipContents.files) {
            var file = zipContents.file(filename);
            if ((!util_1.isUndefined(filename)) && filename !== null) {
                while (filename.indexOf("/") >= 0) {
                    filename = filename.substr(filename.indexOf('/') + 1, filename.length - 1);
                }
            }
            if (file != null && filename !== "" && filename !== ".DS_Store") {
                contents.push(file.async("string"));
            }
        }
        return contents;
    };
    DataController.prototype.room_addGeo = function (array) {
        var instance = this;
        var uniqueAddress = [];
        var tempArray = [];
        var temp = {};
        return new Promise(function (fulfill, reject) {
            for (var _i = 0, array_1 = array; _i < array_1.length; _i++) {
                var room = array_1[_i];
                if (!uniqueAddress.includes(room.rooms_address))
                    uniqueAddress.push(room.rooms_address);
            }
            var _loop_1 = function (addr) {
                tempArray.push(instance.room_fetchGeo(addr)
                    .then(function (result) {
                    temp[addr] = result;
                })
                    .catch(function (err) {
                    console.log(err);
                }));
            };
            for (var _a = 0, uniqueAddress_1 = uniqueAddress; _a < uniqueAddress_1.length; _a++) {
                var addr = uniqueAddress_1[_a];
                _loop_1(addr);
            }
            Promise.all(tempArray)
                .then(function (result) {
                fulfill(temp);
            })
                .catch(function (err) {
                reject(err);
            });
        });
    };
    DataController.prototype.room_fetchGeo = function (address) {
        return new Promise(function (fulfill, reject) {
            address = encodeURI(address);
            var url = "http://skaha.cs.ubc.ca:11316/api/v1/team78/" + address;
            var options = {
                hostname: 'skaha.cs.ubc.ca',
                port: 11316,
                path: '/api/v1/team78/' + address,
                method: 'GET',
                agent: false,
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                }
            };
            http.get(url, function (res) {
                var data = '';
                res.on('data', function (segment) {
                    data += segment.toString();
                });
                res.on('end', function () {
                    fulfill(JSON.parse(data));
                });
                res.on('error', function (err) {
                    console.log(err);
                    reject(err);
                });
            }).end();
        });
    };
    DataController.prototype.room_mapAddrToGeo = function (geoMapping) {
        for (var _i = 0, roomArray_1 = roomArray; _i < roomArray_1.length; _i++) {
            var room = roomArray_1[_i];
            room.rooms_lat = geoMapping[room.rooms_address].lat;
            room.rooms_lon = geoMapping[room.rooms_address].lon;
        }
    };
    DataController.prototype.room_parseContent = function (arrayOfFileContents) {
        var instance = this;
        console.log('Datacontroller -> room_parseContent -> START');
        return new Promise(function (fulfill, reject) {
            var arrayOfJSONObj = [];
            for (var _i = 0, arrayOfFileContents_2 = arrayOfFileContents; _i < arrayOfFileContents_2.length; _i++) {
                var fileContent = arrayOfFileContents_2[_i];
                var pattern = new RegExp(/<a\s.*?<\/a>/);
                if (!pattern.test(fileContent)) {
                    reject({ "code": 400, "body": { "error": "given file is not html" } });
                }
                var pms = instance.room_htmlParser(fileContent).then(function (array) {
                    arrayOfJSONObj.push(array);
                }).catch(function (err) {
                    console.log(err);
                });
            }
            Promise.all([pms]).then(function () {
                if (arrayOfJSONObj.length == 0) {
                    console.log('Datacontroller -> room_parseContent -> reject -> 0');
                    reject({ "code": 400, "body": { "error": "Zip contained no valid data" } });
                }
                else {
                    console.log('Datacontroller -> room_parseContent -> fulfill');
                    fulfill(roomArray);
                }
            }).catch(function () {
                console.log('Datacontroller -> room_parseContent -> reject -> unknown');
                reject({ "code": 400, "body": { "error": "unknow error" } });
            });
        });
    };
    DataController.prototype.room_htmlParser = function (content) {
        var instance = this;
        var parse5 = require('parse5');
        var parser = new parse5.SAXParser({ locationInfo: true });
        var isTbody = false;
        var isTd = false;
        var current;
        return new Promise(function (fulfill, reject) {
            var Readable = require('stream').Readable;
            var isHtml = false;
            var s = new Readable();
            s.push(content);
            s.push(null);
            s.setEncoding('utf8');
            s.pipe(parser);
            var room;
            parser.on("startTag", function (start, attribute) {
                if (start != 'script') {
                    if (start === 'tbody')
                        isTbody = true;
                    if (start === 'td' && isTbody)
                        isTd = true;
                    if (isTd == true && isTbody == true) {
                        current = attribute[0].value;
                    }
                }
            });
            parser.on("endTag", function (res) {
                if (res === 'td' && isTbody)
                    isTd = false;
                if (res === 'tbody') {
                    isTd = false;
                    isTbody = false;
                    fulfill(roomArray);
                }
            });
            parser.on("comment", function (res) {
            });
            parser.on("doctype", function (res) {
            });
            parser.on('text', function (res) {
                res = res.trim();
                if (isTd == true && isTbody == true) {
                    if (res !== "" && current !== null) {
                        if (!util_1.isUndefined(current)) {
                            if (current.indexOf('/') >= 0) {
                                if (!util_1.isUndefined(room) && room != null
                                    && roomArray.indexOf(room) == -1) {
                                    roomArray.push(room);
                                }
                                room = instance.room_find(room);
                            }
                            room = instance.room_initialize(current, res, room);
                        }
                    }
                }
            });
        });
    };
    DataController.prototype.room_initialize = function (attributes, key, room) {
        if (room == null || util_1.isUndefined(room) || attributes == null || util_1.isUndefined(attributes)
            || key == null || util_1.isUndefined(key)) {
            return null;
        }
        if (key === 'More info') {
            return null;
        }
        if (attributes.indexOf('/') >= 0 && attributes.charAt(0) === '.' && key !== '') {
            while (attributes.indexOf('/') >= 0) {
                attributes = attributes.substr(attributes.indexOf('/') + 1, attributes.length);
            }
            room.rooms_shortname = attributes;
            room.rooms_fullname = key;
            return room;
        }
        if (attributes.indexOf('/') >= 0) {
            room.rooms_href = attributes;
            while (attributes.indexOf('/') >= 0) {
                attributes = attributes.substr(attributes.indexOf('/') + 1, attributes.length);
            }
            room.rooms_shortname = attributes.substr(0, attributes.indexOf('-'));
            room.rooms_number = attributes.substr(attributes.indexOf('-') + 1, attributes.length);
            room.rooms_name = room.rooms_shortname + "_" + room.rooms_number;
            return room;
        }
        while (attributes.indexOf('-') >= 0) {
            attributes = attributes.substr(attributes.indexOf('-') + 1, attributes.length);
        }
        switch (attributes) {
            case 'capacity':
                room.rooms_seats = parseInt(key);
                return room;
            case 'furniture':
                room.rooms_furniture = key;
                return room;
            case 'type':
                room.rooms_type = key;
                return room;
            case 'address':
                room.rooms_address = key;
                return room;
            case 'code':
                room.rooms_shortname = key;
                return room;
            case 'nothing':
            case 'image':
            case 'title':
                return room;
            default:
                console.log("FETAL ERROR!! Non-Existing room attribute = " + attributes);
        }
    };
    DataController.prototype.room_find = function (room) {
        if (room == null)
            return new Room_1.default();
        for (var i = 0; i < roomArray.length; i++) {
            if (util_1.isUndefined(room) || room == null) {
                console.log("dsd");
            }
            if (roomArray[i].rooms_shortname === room.rooms_shortname) {
                return roomArray[i];
            }
        }
        return new Room_1.default();
    };
    DataController.prototype.room_validator = function (array) {
        return new Promise(function (fulfill, reject) {
            var temp = [];
            for (var i = 0; i < array.length; i++) {
                if (array[i].rooms_fullname !== 'DEFAULT') {
                    temp.push(array[i]);
                    array.splice(i, 1);
                    i = 0;
                }
            }
            var isFound = false;
            for (var i = 0; i < array.length; i++) {
                isFound = false;
                for (var j = 0; j < temp.length; j++) {
                    isFound = true;
                    if (array[i].rooms_shortname === temp[j].rooms_shortname) {
                        array[i].rooms_address = temp[j].rooms_address;
                        array[i].rooms_fullname = temp[j].rooms_fullname;
                        array[i].rooms_lat = temp[j].rooms_lat;
                        array[i].rooms_lon = temp[j].rooms_lon;
                    }
                }
                if (!isFound) {
                    array.splice(i, 1);
                    i = 0;
                }
                else if (array[i].rooms_fullname === 'DEFAULT') {
                    array.splice(i, 1);
                    i = 0;
                }
            }
            fulfill(array);
        });
    };
    DataController.prototype.cacheData = function (jsonData, id) {
        var fs = require("fs");
        var path = "./cache/";
        var code = 201;
        return new Promise(function (fulfill, reject) {
            if (!fs.existsSync(path)) {
                fs.mkdirSync(path);
            }
            path = path + id + "/";
            if (!fs.existsSync(path)) {
                code = 204;
                fs.mkdirSync(path);
            }
            path = path + id + ".JSON";
            fs.writeFile(path, jsonData, function (err) {
                if (err) {
                }
                else {
                    fulfill({ "code": code, "body": {} });
                }
            });
        });
    };
    DataController.prototype.removeDataset = function (id) {
        var instance = this;
        var path = "./cache/" + id + "/";
        return new Promise(function (fulfill, reject) {
            switch (id) {
                case "courses":
                    instance.loadedCourses.length = 0;
                    break;
                case "rooms":
                    instance.loadedRooms.length = 0;
                    break;
                default:
                    reject({ code: 404, "body": { "error": "source not previously added" } });
            }
            instance.readFilesInDir(path)
                .then(function (files) {
                return Promise.all(instance.deleteFilesInDir(files, path));
            })
                .then(function (result) {
                return instance.removeDirectory(path);
            })
                .then(function (result2) {
                fulfill(result2);
            })
                .catch(function (err) {
                reject(err);
            });
        });
    };
    DataController.prototype.readFilesInDir = function (path) {
        return new Promise(function (fulfill, reject) {
            fs.readdir(path, function (err, files) {
                if (err) {
                    reject({ code: 404, "body": { "error": "source not previously added" } });
                }
                else {
                    fulfill(files);
                }
            });
        });
    };
    DataController.prototype.deleteFilesInDir = function (files, path) {
        var results = [];
        var _loop_2 = function (file) {
            results.push(new Promise(function (fulfill, reject) {
                fs.unlink(path + file, function (err) {
                    if (err) {
                    }
                    fulfill({ code: 204, body: {} });
                });
            }));
        };
        for (var _i = 0, files_1 = files; _i < files_1.length; _i++) {
            var file = files_1[_i];
            _loop_2(file);
        }
        return results;
    };
    DataController.prototype.removeDirectory = function (path) {
        return new Promise(function (fulfill, reject) {
            fs.rmdir(path, function (err) {
                if (err) {
                }
                fulfill({ code: 204, body: {} });
            });
        });
    };
    DataController.prototype.loadCache = function (id) {
        var instance = this;
        var filename = "./cache/" + id + "/" + id + ".JSON";
        try {
            switch (id) {
                case "courses":
                    if (instance.loadedCourses.length == 0)
                        instance.loadedCourses = JSON.parse(fs.readFileSync(filename, "utf8"));
                    return instance.loadedCourses;
                case "rooms":
                    if (instance.loadedRooms.length == 0)
                        instance.loadedRooms = JSON.parse(fs.readFileSync(filename, "utf8"));
                    return instance.loadedRooms;
                default:
                    throw ({ code: 424, body: { missing: [id] } });
            }
        }
        catch (err) {
            throw ({ code: 424, body: { missing: [id] } });
        }
    };
    return DataController;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = DataController;
//# sourceMappingURL=DataController.js.map