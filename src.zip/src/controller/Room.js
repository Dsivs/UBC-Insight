"use strict";
var Room = (function () {
    function Room() {
        this.rooms_fullname = "DEFAULT";
        this.rooms_type = "";
        this.rooms_furniture = "";
    }
    return Room;
}());
Room.roomKeys = ["rooms_fullname", "rooms_shortname", "rooms_number", "rooms_name", "rooms_address", "rooms_lat", "rooms_lon", "rooms_seats", "rooms_type", "rooms_furniture", "rooms_href"];
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Room;
//# sourceMappingURL=Room.js.map