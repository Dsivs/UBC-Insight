"use strict";
var Course_1 = require("./Course");
var Room_1 = require("./Room");
var QueryController = (function () {
    function QueryController() {
        this.validIDs = ["courses", "rooms"];
        this.IDs = [];
    }
    QueryController.prototype.performQuery = function (query, parentInsightFacade) {
        var instance = this;
        var resultsArray = [];
        instance.IDs.length = 0;
        return new Promise(function (fulfill, reject) {
            try {
                var where = query.WHERE;
                var options = query.OPTIONS;
                instance.checkWHEREandOPTIONS(where, options);
                options = instance.checkOptions(options);
                var filterFun = undefined;
                if (Object.keys(where).length != 0)
                    filterFun = instance.parseFilter(where);
                var id = instance.checkInvalidIDs();
                var columns = options.columns;
                var transformations = query.TRANSFORMATIONS;
                instance.checkTFsAndColumnsMatch(transformations, columns, id);
                var loadedData = parentInsightFacade.checkMem(id);
                if (filterFun != undefined) {
                    for (var _i = 0, loadedData_1 = loadedData; _i < loadedData_1.length; _i++) {
                        var obj = loadedData_1[_i];
                        if (filterFun(obj)) {
                            resultsArray.push(obj);
                        }
                    }
                }
                else {
                    resultsArray = loadedData;
                }
                resultsArray = instance.transformData(transformations, resultsArray);
                resultsArray = JSON.parse(JSON.stringify(resultsArray, columns));
                resultsArray = instance.sortData(options.order, resultsArray);
                fulfill({ code: 200, body: { render: 'TABLE', result: resultsArray } });
            }
            catch (err) {
                reject(err);
            }
        });
    };
    QueryController.prototype.checkWHEREandOPTIONS = function (where, options) {
        if (where == undefined)
            throw ({ code: 400, body: { error: "WHERE is missing" } });
        if (options == undefined)
            throw ({ code: 400, body: { error: "OPTIONS is missing" } });
    };
    QueryController.prototype.checkOptions = function (options) {
        var instance = this;
        var order = options.ORDER;
        var orderObj = instance.checkOrder(order);
        var columns = options.COLUMNS;
        instance.checkColumns(columns);
        instance.checkColumnsIncludesOrder(orderObj, columns);
        var form = options.FORM;
        instance.checkForm(form);
        return {
            order: orderObj,
            columns: columns,
            form: form
        };
    };
    QueryController.prototype.checkOrder = function (order) {
        var direction = 1;
        if (order == undefined)
            return undefined;
        if (typeof order == "string") {
            return {
                dir: direction,
                keys: [order]
            };
        }
        var dir = order.dir;
        var keys = order.keys;
        switch (dir) {
            case "UP":
                break;
            case "DOWN":
                direction = -1;
                break;
            default:
                throw ({ code: 400, body: { error: "dir must be UP or DOWN" } });
        }
        if (!Array.isArray(keys))
            throw ({ code: 400, body: { error: "keys must be an array of keys" } });
        if (keys.length == 0)
            throw ({ code: 400, body: { error: "keys must not be empty" } });
        return {
            dir: direction,
            keys: keys
        };
    };
    QueryController.prototype.checkColumns = function (columns) {
        if (!Array.isArray(columns))
            throw ({ code: 400, body: { error: "COLUMNS must be an array" } });
        if (columns.length == 0)
            throw ({ code: 400, body: { error: "COLUMNS cannot be empty" } });
        for (var _i = 0, columns_1 = columns; _i < columns_1.length; _i++) {
            var column = columns_1[_i];
            if (column.includes("_")) {
                var id = column.substring(0, column.indexOf("_"));
                if (!this.IDs.includes(id))
                    this.IDs.push(id);
            }
        }
    };
    QueryController.prototype.checkColumnsIncludesOrder = function (order, columns) {
        if (order != undefined) {
            for (var _i = 0, _a = order.keys; _i < _a.length; _i++) {
                var key = _a[_i];
                if (!columns.includes(key))
                    throw ({ code: 400, body: { error: key + " is not in COLUMNS" } });
            }
        }
    };
    QueryController.prototype.checkForm = function (form) {
        if (form != "TABLE") {
            throw ({ code: 400, body: { error: form + " is not equal to TABLE" } });
        }
    };
    QueryController.prototype.parseFilter = function (filter) {
        var instance = this;
        var numKeys = Object.keys(filter).length;
        if (numKeys != 1)
            throw ({ code: 400, body: { error: "filter must have only one key" } });
        var key = Object.keys(filter)[0];
        var keyValue = filter[key];
        switch (key) {
            case "OR":
            case "AND":
                var arrayOfFilterFn_1 = [];
                if (!Array.isArray(keyValue))
                    throw ({ code: 400, body: { error: "value of " + key + " must be an array" } });
                if (keyValue.length == 0)
                    throw ({ code: 400, body: { error: key + " must have at least one key" } });
                for (var _i = 0, keyValue_1 = keyValue; _i < keyValue_1.length; _i++) {
                    var filter_1 = keyValue_1[_i];
                    arrayOfFilterFn_1.push(instance.parseFilter(filter_1));
                }
                switch (key) {
                    case "OR":
                        return function (CourseObj) {
                            var result = false;
                            for (var _i = 0, arrayOfFilterFn_2 = arrayOfFilterFn_1; _i < arrayOfFilterFn_2.length; _i++) {
                                var filter_2 = arrayOfFilterFn_2[_i];
                                result = result || filter_2(CourseObj);
                            }
                            return result;
                        };
                    case "AND":
                        return function (CourseObj) {
                            var result = true;
                            for (var _i = 0, arrayOfFilterFn_3 = arrayOfFilterFn_1; _i < arrayOfFilterFn_3.length; _i++) {
                                var filter_3 = arrayOfFilterFn_3[_i];
                                result = result && filter_3(CourseObj);
                            }
                            return result;
                        };
                }
            case "GT":
            case "EQ":
            case "LT":
            case "IS":
                var paramFieldLength = Object.keys(keyValue).length;
                if (paramFieldLength != 1)
                    throw ({ code: 400, body: { error: key + " must have exactly one key" } });
                var paramField_1 = Object.keys(keyValue)[0];
                var paramValue_1 = keyValue[paramField_1];
                if (!paramField_1.includes("_"))
                    throw ({ code: 400, body: { error: paramField_1 + " is not a valid key" } });
                var id = paramField_1.substring(0, paramField_1.indexOf("_"));
                if (!this.IDs.includes(id))
                    this.IDs.push(id);
                switch (key) {
                    case "GT":
                    case "EQ":
                    case "LT":
                        if (typeof paramValue_1 != "number")
                            throw ({ code: 400, body: { error: "value of " + key + " must be a number" } });
                        break;
                    case "IS":
                        if (typeof paramValue_1 != "string")
                            throw ({ code: 400, body: { error: "value of " + key + " must be a string" } });
                        break;
                }
                return function (courseObj) {
                    if (courseObj[paramField_1] == undefined)
                        throw ({ code: 400, body: { error: paramField_1 + " is not a valid key" } });
                    if (typeof courseObj[paramField_1] != typeof paramValue_1)
                        throw ({ code: 400, body: { error: "type of " + paramField_1 + " does not match with key value: " + paramValue_1 } });
                    switch (key) {
                        case "GT":
                            return courseObj[paramField_1] > paramValue_1;
                        case "EQ":
                            return courseObj[paramField_1] == paramValue_1;
                        case "LT":
                            return courseObj[paramField_1] < paramValue_1;
                        case "IS":
                            var firstWild = paramValue_1.startsWith("*");
                            var secondWild = paramValue_1.endsWith("*");
                            if (firstWild && secondWild) {
                                return courseObj[paramField_1].includes(paramValue_1.substring(1, paramValue_1.length - 1));
                            }
                            else if (firstWild) {
                                return courseObj[paramField_1].endsWith(paramValue_1.substring(1));
                            }
                            else if (secondWild) {
                                return courseObj[paramField_1].startsWith(paramValue_1.substring(0, paramValue_1.length - 1));
                            }
                            else {
                                return courseObj[paramField_1] === paramValue_1;
                            }
                    }
                };
            case "NOT":
                var filterFn_1 = instance.parseFilter(keyValue);
                return function (courseObj) {
                    return !filterFn_1(courseObj);
                };
            default:
                throw ({ code: 400, body: { error: key + " is not a valid key" } });
        }
    };
    QueryController.prototype.checkInvalidIDs = function () {
        var instance = this;
        if (instance.IDs.length == 1 && instance.validIDs.includes(instance.IDs[0]))
            return instance.IDs[0];
        var missingIDs = [];
        for (var _i = 0, _a = instance.IDs; _i < _a.length; _i++) {
            var id = _a[_i];
            if (!instance.validIDs.includes(id))
                missingIDs.push(id);
        }
        if (missingIDs.length > 0)
            throw ({ code: 424, body: { missing: missingIDs } });
        else
            throw ({ code: 400, body: { error: "cannot query multiple datasets" } });
    };
    QueryController.prototype.checkTFsAndColumnsMatch = function (tfs, columns, id) {
        var instance = this;
        if (tfs == undefined) {
            instance.verifyValidKeys(columns, id);
            return;
        }
        var group = tfs.GROUP;
        var groupKeys = [];
        var applyKeys = [];
        var apply = tfs.APPLY;
        if (!Array.isArray(group))
            throw ({ code: 400, body: { error: "invalid GROUP" } });
        if (!Array.isArray(apply))
            throw ({ code: 400, body: { error: "invalid APPLY" } });
        for (var _i = 0, columns_2 = columns; _i < columns_2.length; _i++) {
            var column = columns_2[_i];
            if (column.includes("_"))
                groupKeys.push(column);
            else
                applyKeys.push(column);
        }
        for (var _a = 0, groupKeys_1 = groupKeys; _a < groupKeys_1.length; _a++) {
            var key = groupKeys_1[_a];
            if (!group.includes(key))
                throw ({ code: 400, body: { error: "COLUMNS keys must match GROUP keys" } });
        }
        for (var _b = 0, group_1 = group; _b < group_1.length; _b++) {
            var term = group_1[_b];
            if (!term.includes("_"))
                throw ({ code: 400, body: { error: "GROUP cannot contain APPLY keys" } });
        }
        instance.verifyValidKeys(group, id);
        var strings = [];
        for (var _c = 0, apply_1 = apply; _c < apply_1.length; _c++) {
            var applyKey = apply_1[_c];
            if (Object.keys(applyKey).length != 1)
                throw ({ code: 400, body: { error: "APPLYKEY must have exactly one string" } });
            var string = Object.keys(applyKey)[0];
            if (string.includes("_"))
                throw ({ code: 400, body: { error: "APPLY keys cannot contain _" } });
            if (strings.includes(string))
                throw ({ code: 400, body: { error: "APPLY strings must be unique" } });
            strings.push(string);
            var applyObj = applyKey[string];
            if (Object.keys(applyObj).length != 1)
                throw ({ code: 400, body: { error: "APPLYKEY must have exactly one APPLYTOKEN" } });
            var applyToken = Object.keys(applyObj)[0];
            switch (applyToken) {
                case "MAX":
                case "MIN":
                case "AVG":
                case "COUNT":
                case "SUM":
                    break;
                default:
                    throw ({ code: 400, body: { error: applyToken + " is not a valid APPLYKEY property" } });
            }
            var key = applyObj[applyToken];
            instance.verifyValidKeys([key], id);
        }
        for (var _d = 0, applyKeys_1 = applyKeys; _d < applyKeys_1.length; _d++) {
            var key = applyKeys_1[_d];
            if (!strings.includes(key))
                throw ({ code: 400, body: { error: "COLUMNS keys must match APPLY keys" } });
        }
    };
    QueryController.prototype.verifyValidKeys = function (keys, id) {
        var validKeys;
        switch (id) {
            case "courses":
                validKeys = Course_1.default.courseKeys;
                break;
            case "rooms":
                validKeys = Room_1.default.roomKeys;
                break;
        }
        for (var _i = 0, keys_1 = keys; _i < keys_1.length; _i++) {
            var key = keys_1[_i];
            if (!validKeys.includes(key))
                throw ({ code: 400, body: { error: key + " is not a valid key" } });
        }
    };
    QueryController.prototype.transformData = function (tfs, data) {
        if (tfs == undefined)
            return data;
        var instance = this;
        var transformedData = [];
        var groupedData = {};
        var group = tfs.GROUP;
        var apply = tfs.APPLY;
        for (var _i = 0, data_1 = data; _i < data_1.length; _i++) {
            var obj = data_1[_i];
            var hash = "";
            for (var _a = 0, group_2 = group; _a < group_2.length; _a++) {
                var term = group_2[_a];
                hash += obj[term];
            }
            if (groupedData[hash] == undefined) {
                var newObj = {};
                for (var _b = 0, group_3 = group; _b < group_3.length; _b++) {
                    var term = group_3[_b];
                    newObj[term] = obj[term];
                }
                groupedData[hash] = newObj;
            }
            instance.applyTFs(groupedData[hash], obj, apply);
        }
        instance.processAVGCOUNT(groupedData);
        for (var key in groupedData) {
            transformedData.push(groupedData[key]);
        }
        return transformedData;
    };
    QueryController.prototype.applyTFs = function (group, dataObj, apply) {
        var instance = this;
        for (var _i = 0, apply_2 = apply; _i < apply_2.length; _i++) {
            var applyKey = apply_2[_i];
            var string = Object.keys(applyKey)[0];
            var applyToken = Object.keys(applyKey[string])[0];
            var applyProp = applyKey[string][applyToken];
            var dataValue = dataObj[applyProp];
            switch (applyToken) {
                case "MAX":
                case "MIN":
                case "AVG":
                case "SUM":
                    if (typeof dataValue != "number")
                        throw ({ code: 400, body: { error: applyToken + " must be applied to number data" } });
                    instance.doOperations(applyToken, group, string, dataValue);
                    break;
                case "COUNT":
                    instance.doOperations(applyToken, group, string, dataValue);
                    break;
            }
        }
    };
    QueryController.prototype.doOperations = function (op, group, field, newVal) {
        var instance = this;
        switch (op) {
            case "MAX":
                if (group[field] == undefined)
                    group[field] = newVal;
                if (group[field] < newVal)
                    group[field] = newVal;
                break;
            case "MIN":
                if (group[field] == undefined)
                    group[field] = newVal;
                if (group[field] > newVal)
                    group[field] = newVal;
                break;
            case "SUM":
                if (group[field] == undefined)
                    group[field] = 0;
                group[field] += newVal;
                break;
            case "AVG":
                if (group[field] == undefined) {
                    group[field] = {};
                    group[field].sum = 0;
                    group[field].numBuffer = 0;
                }
                newVal *= 10;
                newVal = Number(newVal.toFixed(0));
                group[field].sum += newVal;
                group[field].numBuffer++;
                break;
            case "COUNT":
                if (group[field] == undefined) {
                    group[field] = {};
                    group[field].num = 0;
                    group[field].uniqueBuffer = [];
                }
                if (!group[field].uniqueBuffer.includes(newVal)) {
                    group[field].num++;
                    group[field].uniqueBuffer.push(newVal);
                }
                break;
        }
    };
    QueryController.prototype.processAVGCOUNT = function (groupedData) {
        var instance = this;
        for (var key in groupedData) {
            var row = groupedData[key];
            for (var subkey in row) {
                if (typeof row[subkey] == "object") {
                    if (row[subkey].sum)
                        row[subkey] = instance.doMath(row[subkey].sum, row[subkey].numBuffer);
                    else
                        row[subkey] = row[subkey].num;
                }
            }
        }
    };
    QueryController.prototype.doMath = function (curVal, count) {
        curVal /= count;
        curVal /= 10;
        curVal = Number(curVal.toFixed(2));
        return curVal;
    };
    QueryController.prototype.sortData = function (order, data) {
        if (order == undefined)
            return data;
        var dir = order.dir;
        var keys = order.keys;
        data.sort(function (a, b) {
            var i = 0;
            do {
                if (a[keys[i]] > b[keys[i]]) {
                    return dir;
                }
                else if (a[keys[i]] < b[keys[i]]) {
                    return -dir;
                }
                i++;
            } while (i < keys.length);
            return 0;
        });
        return data;
    };
    return QueryController;
}());
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = QueryController;
//# sourceMappingURL=QueryController.js.map