"use strict";
var Course = (function () {
    function Course(dept, id, avg, instructor, title, pass, fail, audit, uuid, year) {
        this.courses_dept = dept;
        this.courses_id = id;
        this.courses_avg = avg;
        this.courses_instructor = instructor;
        this.courses_title = title;
        this.courses_pass = pass;
        this.courses_fail = fail;
        this.courses_size = pass + fail;
        this.courses_audit = audit;
        this.courses_uuid = uuid;
        this.courses_year = year;
    }
    return Course;
}());
Course.courseKeys = ["courses_dept", "courses_id", "courses_avg", "courses_instructor", "courses_title", "courses_pass", "courses_fail", "courses_audit", "courses_uuid", "courses_year"];
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Course;
//# sourceMappingURL=Course.js.map